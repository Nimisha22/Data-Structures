#include<stdio.h>

struct stac
{
	int stk[100];
	int top;
}s;
 void push(int item)
 {
 	s.top++;
 	s.stk[s.top]=item;
 }
 
 int pop()
{
	return(s.top--);
}

int sum(int n)
{
	int sum=0,i;
	for(i=1;i<=n;i++)
	push(i);
	for(i=1;i<=n;i++)
	 sum+= pop();
	
	return sum;
}

int main()
{
	int n;
	printf("ENTER THE NUMBER:");
	scanf("%d",&n);
	
	printf("sum of numbers from 1 to %d is %d",n,sum(n));
	return 0;
}

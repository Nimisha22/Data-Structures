 #include<stdio.h>
 #include<conio.h>
 struct queue 
 { 
    int que [100];
    int top; 
 }q; 
 
 void enqueue(int item) 
 { 
    int i,temp=0; 
    q.top++; 
    q.que[q.top] =  item; 
 } 
 
 void dequeue()
 { 
    int i ; 
    for (i=0;i<q.top;i++) 
         q.que[i]=q.que[i+1]; 
    q.top--; 
 } 
 
 int main()
 { 
    q.top=-1; 
    int i,n,k,sum=0 ; 
    printf("ENTER NUMBER OF PEOPLE:");
    scanf("%d",&n);
    printf("ENTER NUMBER OF PEOPLE TO SKIP");
    scanf("%d",&k);
    for(i=1;i<=n;i++)
	{  
     sum = (sum + k) % i; 
     enqueue(sum+ 1 );
    }
    printf("THE CHOOSEN PLACE IS %d",q.que[q.top]);
    return 0; 
 } 

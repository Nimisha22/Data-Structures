#include <stdio.h>
#include <limits.h>
#include <stdlib.h>

#define N 10
#define INFINITY INT_MAX

typedef struct linked_list LinkedList;

struct linked_list {
    int data, weight;
    LinkedList *next;
};

// Function for creating a new node and returning that node.
LinkedList *newNode() {
    int vertex, weight;
    printf("\nEnter Node Number: ");
    scanf("%d", &vertex);
    printf("\nEnter Weight: ");
    scanf("%d", &weight);
    
    // Allocating new node 'n'.
    LinkedList *n;
    n = (LinkedList *)malloc(sizeof(LinkedList));
    n->data = vertex;
    n->weight = weight;
    n->next = NULL;
    return n;
}

// Function for adding new node to the head list.
void addNode(LinkedList **head) { // Pass-by-reference
    LinkedList *n = newNode();
    // Getting head in temp node
    LinkedList *temp = *head;
    while(temp->next){
        temp = temp->next;
    }
    temp->next = n;
}

void displayList(LinkedList *head) {
    while(head) {
        printf(" -> %d:%d ", head->data, head->weight);
        head = head->next;
    }
}

void displayAdjacencyList(LinkedList *t_head[], int n) {
    int i;
    LinkedList *temp;
    printf("\n\nDisplaying Adjacency List.");
    for(i = 0; i < n; i++) {
        temp = t_head[i];
        printf("\n\nVertex[%d]", temp->data);
        temp = temp->next;
        displayList(temp);
    }
}

void printArray(int arr[], int n) {
    int i;
    for(i = 0; i < n; i++) {
        printf("%d", arr[i]);
        if(i < n - 1) // So commas are not printed at the end.
            printf(", ");
    }
}

int getMinimumDistance(int distance[], int visited[], int n) {
    int i, min = INFINITY, min_index = -1;
    for(i = 0; i < n; i++) {
        if(!visited[i] && distance[i] <= min) {
            min = distance[i];
            min_index = i;
        }
    }
    return min_index;
}

void djikstras(LinkedList *head[], int n) {
    int i;
    int source;
    int visited[N] = { 0 }; // To keep track of the visited nodes
    int distance[N] = { 0 }; // To keep track of the distances of source to all vertices.
    printf("\n\n**** Djikstra's Shortest Path - Single Source, Multiple Destination ****");
    printf("\n\nEnter Source Vertex: ");
    scanf("%d", &source);

    // Mark all nodes as INFINITY
    for(i = 0; i < n; i++) {
        distance[i] = INFINITY;
    }

    distance[source-1] = 0; // source-1 because nodes are numbered from 1 - n.

    printf("\nDistance Vector for %d as Source (Initially):\n\n", source);
    printArray(distance, n);

    // Outer loop traverse till n-1 because we dont check with source vertex.
    for(i = 0; i < n; i++) {
        int u = getMinimumDistance(distance, visited, n);
        visited[u] = 1; // Mark node as visited.
        LinkedList *temp = head[u]; // Getting the uth list.
        printf("\n\nOn Node[%d]: ", temp->data);
        printArray(distance, n);
        temp = temp->next; // Go to next for first adjacent node.
        while(temp) {
            /*
                This complicated if condition is really simple actually.
                First Condition: d[u] + cost(u, v) < d[v]
                Second Condition: If it is not Infinity, because addition with that will result in seg fault error.
                Third Condition: If it is not already visited
            */
            if(distance[u] + temp->weight < distance[temp->data - 1] &&
               distance[u] != INFINITY && !visited[temp->data - 1])
                distance[temp->data - 1] = distance[u] + temp->weight;
            temp = temp->next; // Run till list is null.
        }
    }
    printf("\n\nFinal Shortest Distances from %d: ", source);
    printArray(distance, n);
}

void helper() {
    // Helper function for modularity
    int i, j, n, counter = 0, adjVerticesN;
    LinkedList *head[N];
    printf("\nEnter Number of Edges: ");
    scanf("%d", &n);

    for(i = 0; i < n; i++) {
        // Create Linked Lists for every node.
        printf("\nAllocating List for Vertex[%d].", ++counter);
        head[i] = (LinkedList *)malloc(sizeof(LinkedList));
        head[i]->data = counter;
        head[i]->next = NULL;
        printf("\n\nEnter Number of Adjacent Vertices: ");
        scanf("%d", &adjVerticesN);
        for(j = 0; j < adjVerticesN; j++) {
            addNode(&head[i]);
        }
    }
    displayAdjacencyList(head, n);
    djikstras(head, n);
}

int main()
{
    helper();
    getche();
    return 0;
}

/*Saniya S. Inamdar
201900913
R.no 17
Ds assn 2
PROGRAM TO INSERT AN ELEMENT IN THE SORTED POSITION OF A GIVEN SORTED LIST.
*/


#include<stdio.h>
#include<stdlib.h>


struct Node
{
	int data;
	struct Node* next;
};


void printList(struct Node* head)
{
	struct Node* ptr = head;
	while (ptr)
	{
		printf("%d -> ", ptr->data);
		ptr = ptr->next;
	}

	printf("null");
}


void push(struct Node** head, int data)
{
	struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
	newNode->data = data;
	newNode->next = *head;
	*head = newNode;
}


struct Node* newNode(int data)
{
	struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
	newNode->data = data;
	newNode->next = NULL;
	return newNode;
}


void sortedInsert(struct Node** head, struct Node* newNode)
{

	if (*head == NULL || (*head)->data >= newNode->data)
	{
		newNode->next = *head;
		*head = newNode;
		return;
	}


	struct Node* current = *head;
	while (current->next != NULL && current->next->data < newNode->data)
		current = current->next;

	newNode->next = current->next;
	current->next = newNode;
}

int main(void)
{
    int data,num;


	printf("CTREATE A SORTED DOUBLE LINKED LIST\n");
    printf("\nEnter the number of nodes you want to create: ");
    scanf("%d", &num);
    int keys[num];
    for(int i=0;i<num;i++){
        printf("Enter dta of %d node: ",i+1);
        scanf("%d",&keys[i]);
    }

	int n = sizeof(keys)/sizeof(keys[0]);


	struct Node* head = NULL;

	// Create linked list
	for (int i = n-1; i >= 0; i--)
		push(&head, keys[i]);

    printf("\nEnter the number of nodes you want to insert: ");
    scanf("%d", &num);

    for(int i=0;i<num;i++){
        printf("Enter the data of number %d node to be inserted:", i+1);
        scanf("%d", &data);
        sortedInsert(&head, newNode(data));
    }


	printList(head);

	return 0;
}

/*OUTPUT
CTREATE A SORTED DOUBLE LINKED LIST

Enter the number of nodes you want to create: 2
Enter dta of 1 node: 1
Enter dta of 2 node: 3

Enter the number of nodes you want to insert: 1
Enter the data of number 1 node to be inserted:2
1 -> 2 -> 3

*/

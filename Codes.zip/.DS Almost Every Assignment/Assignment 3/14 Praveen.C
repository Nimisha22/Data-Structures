#include<stdio.h>
#include<stdlib.h>

struct node
{
  int data;
  struct node *next;
}*head;

void create_list(int n);
int insert_sort(int data);
void print_list();

int main()
{
    int n,choice;
    printf("ENTER THE TOTAL NODES YOU WANT:");
    scanf("%d",&n);
    create_list(n);
    printf("DATA IN THE LISTS : \n");
    print_list();
    printf("\nPRESS 1 TO SORT THE SINGLY LINKED LIST: \n");
    scanf("%d",&choice);
    if(choice == 1)
    {
       int insert_sort();
    }
    printf("\n DATA IN THE LIST: \n");
    print_list();
    return 0;
}
void create_list(int n)
{
   struct node *newnode,*temp;
   int data,i;
   if(n<0)
   {
	 printf("SIZE MUST BE GREATER THAN 0");
	 return;
   }
   head=(struct node*)malloc(sizeof(struct node));
   if(head == NULL)
   {
     printf("CANT ALLOCATE MEMORY\n");
   }
   else
   {
     printf("ENTER DATA IN NODE 1 : ");
     scanf("%d",&data);
     head->data=data;
     head->next=NULL;
     temp=head;
     for(i=2;i<=n;i++)
     {
       newnode=(struct node*)malloc(sizeof(struct node));
       if(newnode==NULL)
       {
	  printf("CANT ALLOCATE MEMORY\n");
	  break;
       }
       else
       {
	  printf("ENTER DATA OF NODE %d  :",i);
	  scanf("%d",&data);
	  newnode->data=data;
	  newnode->next=NULL;
	  temp->next=newnode;
	  temp=temp->next;
       }
     }
    } printf("SINGLY LINKED LIST SUCCESSFULLY CREATED");
}
int insert_sort(int data)
{
   struct node *temp=head;
   struct node *prev=NULL;
   struct node *ptr;

   ptr = (struct node*)malloc(sizeof(struct node));
   ptr->data=data;
   ptr->next=NULL;

   if(temp == NULL)
   {
	ptr->next=NULL;
	head=ptr;
	return 0;
   }
   if(data<temp->data)
   {
       ptr->next=head;
       head=ptr;
       return 0;
   }
   else
   {
       while(temp!=NULL)
       {
	    if(data>temp->data)
	    {
		prev=temp;
		temp=temp->next;
		continue;
	    }
	    else
	    {
		prev->next=ptr;
		ptr->next=temp;
		return 0;
	    }
       }
       prev->next=ptr;
   }
   return 0;
}

void print_list()
{
   struct node *temp=head;
   printf("\nLIST:");
   while(temp!=NULL)
   {
      printf("\n%d",temp->data);
      temp=temp->next;
   }
}




























































































